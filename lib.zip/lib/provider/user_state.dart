import 'package:get/get.dart';

class UserState extends GetxController{
  final userList = [].obs;


}