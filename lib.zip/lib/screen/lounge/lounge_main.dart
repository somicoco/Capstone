import 'package:flutter/material.dart';

class Logungi extends StatefulWidget {
  const Logungi({super.key});

  @override
  State<Logungi> createState() => _LogungiState();
}

class _LogungiState extends State<Logungi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),

    );
  }
}
