// import 'package:flutter_naver_map/flutter_naver_map.dart';
//
// class LocationClass extends NLatLng {
//   const LocationClass({super.key});
//
//   @override
//   State<LocationClass> createState() => _LocationClassState();
// }
//
// class _LocationClassState extends State<LocationClass> {
//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }
